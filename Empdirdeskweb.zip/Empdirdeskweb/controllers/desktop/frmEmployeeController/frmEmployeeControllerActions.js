define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for headerLogoutButton **/
    AS_Button_e517ae9e772d433f89463dc159290281: function AS_Button_e517ae9e772d433f89463dc159290281(eventobject) {
        var self = this;

        function SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_True() {}
        function INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Failure(error) {
            function SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_Callback() {
                SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Success, INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Failure);
    },
    /** onrowclick defined for employeeSegment **/
    AS_Segment_a81b0efd866645e0bcd9839b4fbf34c0: function AS_Segment_a81b0efd866645e0bcd9839b4fbf34c0(eventobject, sectionNumber, rowNumber) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__e0634d46eb2844c5a2bc7c5923142574_Callback(employees) {
            self.view.employeeDetailImage.src = employees["records"][0]["Image_URL"];
            self.view.employeeNameLabel.text = employees["records"][0]["Name"];
            self.view.employeeTitleLabel.text = employees["records"][0]["Designation"];
            self.view.employeeDetailsValue1.text = employees["records"][0]["Email"];
            self.view.employeeDetailsValue2.text = employees["records"][0]["Primary_Phone"];
            self.view.employeeDetailsValue3.text = employees["records"][0]["Department"];
            self.view.employeeDetailsValue4.text = employees["records"][0]["Manager_Name"];
            self.view.detailContainer.isVisible = true;
            self.view.forceLayout();
        }
        selectedEmployeeId = this.view.employeeSegment.selectedRowItems[0].employeeId.text;
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var odataParams = [];
        odataParams.push("$filter=" + "Emp_id eq " + selectedEmployeeId);
        employees_inputparam["options"]["odataurl"] = odataParams.join("&");
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__e0634d46eb2844c5a2bc7c5923142574_Callback);
    },
    /** onclick defined for detailsLogoutButton **/
    AS_Button_e98496d5716345059d55f34f7de4694d: function AS_Button_e98496d5716345059d55f34f7de4694d(eventobject) {
        var self = this;

        function SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_True() {}
        function INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Failure(error) {
            function SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_Callback() {
                SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Success, INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Failure);
    },
    /** onclick defined for detailsPrevButton **/
    AS_Button_hd26818bce214325b74cbcb701025aa9: function AS_Button_hd26818bce214325b74cbcb701025aa9(eventobject) {
        var self = this;
        self.view.detailContainer.isVisible = false;
    },
    /** onmapping defined for frmEmployee **/
    AS_Form_ge3d418bd5c6446e82153b121b5481be: function AS_Form_ge3d418bd5c6446e82153b121b5481be(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__eeb36d84a31d414c95a1a7c7f56eb45b_Callback(employees) {
            kony.application.dismissLoadingScreen();
            var tempCollection4671 = [];
            var tempData2394 = employees.records;
            for (var each in tempData2394) {
                tempCollection4671.push({
                    "employeeSegImage": {
                        "src": tempData2394[each]["Image_URL"]
                    },
                    "employeeId": {
                        "text": tempData2394[each]["Emp_id"]
                    },
                    "employeeFieldName": {
                        "text": tempData2394[each]["Name"]
                    },
                    "employeeFieldTitle": {
                        "text": tempData2394[each]["Designation"]
                    },
                    "employeeFieldGroup": {
                        "text": tempData2394[each]["Department"]
                    },
                });
            }
            self.view.employeeSegment.setData(tempCollection4671);
        }
        kony.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__eeb36d84a31d414c95a1a7c7f56eb45b_Callback);
    }
});