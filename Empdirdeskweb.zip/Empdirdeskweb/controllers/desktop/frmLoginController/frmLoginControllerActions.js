define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for loginButton **/
    AS_Button_e20557e051ad409088db247549f387d9: function AS_Button_e20557e051ad409088db247549f387d9(eventobject) {
        var self = this;

        function SHOW_ALERT__ac07a2f0884d4101a70bc5b95b904c4f_True() {}
        function INVOKE_IDENTITY_SERVICE__h900451939d8456a8cf31d4b9cc37c2a_Success(response) {
            var ntf = new kony.mvc.Navigation("frmEmployee");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__h900451939d8456a8cf31d4b9cc37c2a_Failure(error) {
            function SHOW_ALERT__ac07a2f0884d4101a70bc5b95b904c4f_Callback() {
                SHOW_ALERT__ac07a2f0884d4101a70bc5b95b904c4f_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__ac07a2f0884d4101a70bc5b95b904c4f_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "employeeLogin$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.usernameTextbox.text;
        login_inputparam["password"] = self.view.passwordTextbox.text;
        employeeLogin$login = mfidentityserviceinvoker("employeeLogin", login_inputparam, INVOKE_IDENTITY_SERVICE__h900451939d8456a8cf31d4b9cc37c2a_Success, INVOKE_IDENTITY_SERVICE__h900451939d8456a8cf31d4b9cc37c2a_Failure);
    }
});