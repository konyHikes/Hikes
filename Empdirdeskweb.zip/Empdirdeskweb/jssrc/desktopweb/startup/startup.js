kony.globals["appid"] = "EmployeeDirectory";
kony.globals["build"] = "release";
kony.globals["locales"] = [];
kony.globals["i18nArray"] = [];
//startup.js
var appConfig = {
    appId: "EmployeeDirectory",
    appName: "EmployeeDirectory",
    appVersion: "1.0.0",
    isturlbase: "https://vivekiyer1.konycloud.com/services",
    isDebug: false,
    isMFApp: true,
    appKey: "f3198fb62580b1e544fdf7306690c747",
    appSecret: "4592682752b75ea467af0484f48d450b",
    serviceUrl: "https://100000239.auth.konycloud.com/appconfig",
    svcDoc: {
        "selflink": "https://100000239.auth.konycloud.com/appconfig",
        "identity_meta": {},
        "app_version": "1.0",
        "service_doc_etag": "000001677923CE68",
        "appId": "7c56ac93-0573-4bef-bc36-4204c3680969",
        "identity_features": {
            "reporting_params_header_allowed": true
        },
        "name": "EmpDirectoryApplication",
        "reportingsvc": {
            "session": "https://vivekiyer1.konycloud.com/services/IST",
            "custom": "https://vivekiyer1.konycloud.com/services/CMS"
        },
        "baseId": "7a70bf0b-eb77-4a31-93ae-d0baf25c167d",
        "app_default_version": "1.0",
        "login": [{
            "alias": "employeeLogin",
            "type": "basic",
            "prov": "employeeLogin",
            "url": "https://100000239.auth.konycloud.com"
        }],
        "services_meta": {
            "employeeObjectService": {
                "offline": false,
                "metadata_url": "https://vivekiyer1.konycloud.com/services/metadata/v1/employeeObjectService",
                "type": "objectsvc",
                "version": "1.0",
                "url": "https://vivekiyer1.konycloud.com/services/data/v1/employeeObjectService"
            }
        }
    },
    eventTypes: ["FormEntry", "Error", "Crash"],
};
sessionID = "";

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        responsive: true,
        APILevel: 8400
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    requirejs.config({
        baseUrl: kony.appinit.getStaticContentPath() + 'desktopweb/appjs'
    });
    require(['kvmodules'], function() {
        applicationController = require("applicationController");
        kony.application.setApplicationInitializationEvents({
            init: applicationController.appInit,
            postappinit: applicationController.postAppInitCallBack,
            showstartupform: function() {
                new kony.mvc.Navigation("frmLogin").navigate();
            }
        });
    });
};

function loadResources() {
    kony.theme.packagedthemes(["default"]);
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //This is the entry point for the application.When Locale comes,Local API call will be the entry point.
    loadResources();
};
kony.print = function() {
    return;
};