define("userFBox0ef65618e166341Controller", {
    //Type your controller code here 
});
define("FBox0ef65618e166341ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("FBox0ef65618e166341Controller", ["userFBox0ef65618e166341Controller", "FBox0ef65618e166341ControllerActions"], function() {
    var controller = require("userFBox0ef65618e166341Controller");
    var controllerActions = ["FBox0ef65618e166341ControllerActions"];
    for (var i = 0; i < controllerActions.length; i++) {
        var actions = require(controllerActions[i]);
        for (var key in actions) {
            controller[key] = actions[key];
        }
    }
    return controller;
});
