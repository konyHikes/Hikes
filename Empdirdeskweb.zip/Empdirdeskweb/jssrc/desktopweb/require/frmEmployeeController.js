define("userfrmEmployeeController", {
    //Type your controller code here 
});
define("frmEmployeeControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_ge3d418bd5c6446e82153b121b5481be: function AS_Form_ge3d418bd5c6446e82153b121b5481be(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__eeb36d84a31d414c95a1a7c7f56eb45b_Callback(list_view) {
            kony.application.dismissLoadingScreen();
            var tempCollection786 = [];
            var tempData9194 = list_view.records;
            for (var each in tempData9194) {
                tempCollection786.push({
                    "employeeFieldGroup": {
                        "text": tempData9194[each]["Department"]
                    },
                    "employeeFieldTitle": {
                        "text": tempData9194[each]["Designation"]
                    },
                    "employeeFieldName": {
                        "text": tempData9194[each]["Employee_Name"]
                    },
                    "employeeId": {
                        "text": tempData9194[each]["Emp_id"]
                    },
                    "employeeSegImage": {
                        "src": tempData9194[each]["Image_URL"]
                    },
                });
            }
            self.view.employeeSegment.setData(tempCollection786);
        }
        kony.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (list_view_inputparam == undefined) {
            var list_view_inputparam = {};
        }
        list_view_inputparam["serviceID"] = "employeeObjectService$list_view$get";
        list_view_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var list_view_httpheaders = {};
        list_view_inputparam["httpheaders"] = list_view_httpheaders;
        var list_view_httpconfigs = {};
        list_view_inputparam["httpconfig"] = list_view_httpconfigs;
        employeeObjectService$list_view$get = mfobjectsecureinvokerasync(list_view_inputparam, "employeeObjectService", "list_view", INVOKE_OBJECT_SERVICE__eeb36d84a31d414c95a1a7c7f56eb45b_Callback);
    },
    AS_Button_e517ae9e772d433f89463dc159290281: function AS_Button_e517ae9e772d433f89463dc159290281(eventobject) {
        var self = this;

        function SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_True() {}

        function INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }

        function INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Failure(error) {
            function SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_Callback() {
                SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__db56ca44fd704bd2a1655b3dd86ca997_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Success, INVOKE_IDENTITY_SERVICE__d983f17f94e841979e0e3775669ad64e_Failure);
    },
    AS_Segment_a81b0efd866645e0bcd9839b4fbf34c0: function AS_Segment_a81b0efd866645e0bcd9839b4fbf34c0(eventobject, sectionNumber, rowNumber) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__e0634d46eb2844c5a2bc7c5923142574_Callback(details_view) {
            self.view.employeeDetailsValue3.text = details_view["records"][0]["Department"];
            self.view.employeeTitleLabel.text = details_view["records"][0]["Designation"];
            self.view.employeeDetailsValue1.text = details_view["records"][0]["Email"];
            self.view.employeeDetailsLabel2.text = details_view["records"][0]["Primary_Phone"];
            self.view.employeeNameLabel.text = details_view["records"][0]["Name"];
            self.view.employeeDetailImage.src = details_view["records"][0]["Image_URL"];
            self.view.employeeDetailsLabel1.text = details_view["records"][0]["Manager_Name"];
            self.view.detailContainer.isVisible = true;
            self.view.forceLayout();
        }
        selectedEmployeeId = this.view.employeeSegment.selectedRowItems[0].employeeId.text;
        if (details_view_inputparam == undefined) {
            var details_view_inputparam = {};
        }
        details_view_inputparam["serviceID"] = "employeeObjectService$details_view$get";
        details_view_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var odataParams = [];
        odataParams.push("$filter=" + 'Emp_id eq ' + selectedEmployeeId);
        details_view_inputparam["options"]["odataurl"] = odataParams.join("&");
        var details_view_httpheaders = {};
        details_view_inputparam["httpheaders"] = details_view_httpheaders;
        var details_view_httpconfigs = {};
        details_view_inputparam["httpconfig"] = details_view_httpconfigs;
        employeeObjectService$details_view$get = mfobjectsecureinvokerasync(details_view_inputparam, "employeeObjectService", "details_view", INVOKE_OBJECT_SERVICE__e0634d46eb2844c5a2bc7c5923142574_Callback);
    },
    AS_Button_e98496d5716345059d55f34f7de4694d: function AS_Button_e98496d5716345059d55f34f7de4694d(eventobject) {
        var self = this;

        function SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_True() {}

        function INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }

        function INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Failure(error) {
            function SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_Callback() {
                SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT_onClick_j2a21e4d9a47417284939963a6565a74_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Success, INVOKE_IDENTITY_SERVICE_onClick_b0093358e557428da5428fed1ffb92e1_Failure);
    },
    AS_Button_hd26818bce214325b74cbcb701025aa9: function AS_Button_hd26818bce214325b74cbcb701025aa9(eventobject) {
        var self = this;
        self.view.detailContainer.isVisible = false;
    }
});
define("frmEmployeeController", ["userfrmEmployeeController", "frmEmployeeControllerActions"], function() {
    var controller = require("userfrmEmployeeController");
    var controllerActions = ["frmEmployeeControllerActions"];
    for (var i = 0; i < controllerActions.length; i++) {
        var actions = require(controllerActions[i]);
        for (var key in actions) {
            controller[key] = actions[key];
        }
    }
    return controller;
});
