define("frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var masterContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "masterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "whiteContainerSkin0j841d51650cb44",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            masterContainer.setDefaultUnit(kony.flex.DP);
            var paddingContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "paddingContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "40dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": 40,
                "skin": "slFbox0cc84092c99b040",
                "top": "0dp",
                "width": "380dp"
            }, {}, {});
            paddingContainer.setDefaultUnit(kony.flex.DP);
            var companyLogoImage = new kony.ui.Image2({
                "centerX": "50.00%",
                "height": "123dp",
                "id": "companyLogoImage",
                "isVisible": true,
                "left": "100dp",
                "skin": "slImage0c5ae26e55a794a",
                "src": "logo.png",
                "top": "197dp",
                "width": "123dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var loginTitleContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "43dp",
                "id": "loginTitleContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox0cc84092c99b040",
                "top": "13dp",
                "zIndex": 1
            }, {}, {});
            loginTitleContainer.setDefaultUnit(kony.flex.DP);
            var loginTitleEmployee = new kony.ui.Label({
                "id": "loginTitleEmployee",
                "isVisible": true,
                "left": 0,
                "right": "49.50%",
                "skin": "CopydefLabel0a1625304cbb544",
                "text": "Employee",
                "textStyle": {},
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var loginTitleDirectory = new kony.ui.Label({
                "id": "loginTitleDirectory",
                "isVisible": true,
                "left": "51.50%",
                "right": "0%",
                "skin": "CopydefLabel0c9f04f79d9f645",
                "text": "Directory",
                "textStyle": {},
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            loginTitleContainer.add(loginTitleEmployee, loginTitleDirectory);
            var usernameFieldContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "53dp",
                "id": "usernameFieldContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox0cc84092c99b040",
                "top": "10.560000000000002%",
                "zIndex": 1
            }, {}, {});
            usernameFieldContainer.setDefaultUnit(kony.flex.DP);
            var usernameLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "usernameLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 20,
                "skin": "sepLineSkin0a93584b25ac64d",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            usernameLine.setDefaultUnit(kony.flex.DP);
            usernameLine.add();
            var usernameTextbox = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "loginFieldSkinFocus0c6baf0e46e3346",
                "height": "100%",
                "id": "usernameTextbox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Username",
                "secureTextEntry": false,
                "skin": "loginFieldSkin0d1307efeade948",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "CopydefTextBoxPlaceholder0i74069f235f246"
            });
            usernameFieldContainer.add(usernameLine, usernameTextbox);
            var passwordFIeldContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "53dp",
                "id": "passwordFIeldContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox0cc84092c99b040",
                "top": "3.8999999999999986%",
                "zIndex": 1
            }, {}, {});
            passwordFIeldContainer.setDefaultUnit(kony.flex.DP);
            var passwordLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "passwordLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 20,
                "skin": "sepLineSkin0a93584b25ac64d",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            passwordLine.setDefaultUnit(kony.flex.DP);
            passwordLine.add();
            var passwordTextbox = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "CopydefTextBoxNormal0h8584fef8dc041",
                "height": "100%",
                "id": "passwordTextbox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Password",
                "secureTextEntry": false,
                "skin": "loginFieldSkin0d1307efeade948",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "CopydefTextBoxPlaceholder0i74069f235f246"
            });
            passwordFIeldContainer.add(passwordLine, passwordTextbox);
            var loginButton = new kony.ui.Button({
                "focusSkin": "blueButtonSkinFocus0bdae35a9181b4d",
                "height": "50dp",
                "id": "loginButton",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_e20557e051ad409088db247549f387d9,
                "right": 0,
                "skin": "blueButtonSkin0hd4cd0bc27634a",
                "text": "Login",
                "top": "37dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            paddingContainer.add(companyLogoImage, loginTitleContainer, usernameFieldContainer, passwordFIeldContainer, loginButton);
            masterContainer.add(paddingContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "480": {
                    "companyLogoImage": {
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        }
                    },
                    "loginTitleContainer": {
                        "height": {
                            "type": "string",
                            "value": "33dp"
                        }
                    }
                }
            }
            this.add(masterContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [480, 771, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});