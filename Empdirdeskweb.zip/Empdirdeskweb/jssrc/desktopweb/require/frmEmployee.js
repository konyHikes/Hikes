define("frmEmployee", function() {
    return function(controller) {
        function addWidgetsfrmEmployee() {
            this.setDefaultUnit(kony.flex.DP);
            var masterContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "masterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "whiteContainerSkin0j1a79816e5b549",
                "top": "0dp",
                "width": "100%"
            }, {}, {});
            masterContainer.setDefaultUnit(kony.flex.DP);
            var headerContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "headerContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0fa636ea1d7714b",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            headerContainer.setDefaultUnit(kony.flex.DP);
            var headerDivider = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "headerDivider",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sepLineSkin0jc56bddf12a349",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            headerDivider.setDefaultUnit(kony.flex.DP);
            headerDivider.add();
            var headerTitle = new kony.ui.Label({
                "bottom": "18dp",
                "centerX": "50%",
                "id": "headerTitle",
                "isVisible": true,
                "left": "139dp",
                "skin": "CopydefLabel0e64ba49331f649",
                "text": "Employee List",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var headerLogoutImage = new kony.ui.Image2({
                "centerY": "50%",
                "height": "22dp",
                "id": "headerLogoutImage",
                "isVisible": true,
                "right": 16,
                "skin": "slImage0e0fb4aee452048",
                "src": "logouticon.png",
                "top": "16dp",
                "width": "22dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var headerLogoutButton = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0cd563ad946534f",
                "height": "100%",
                "id": "headerLogoutButton",
                "isVisible": true,
                "onClick": controller.AS_Button_e517ae9e772d433f89463dc159290281,
                "right": 0,
                "skin": "headerButtonSkin0b7021b36f50840",
                "text": "Button",
                "top": "0dp",
                "width": "56dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": false,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var headerBackChevron = new kony.ui.Image2({
                "centerY": "50%",
                "height": "18dp",
                "id": "headerBackChevron",
                "isVisible": false,
                "left": 14,
                "right": 16,
                "skin": "slImage0e0fb4aee452048",
                "src": "backicon.png",
                "top": "16dp",
                "width": "18dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var headerBackButton = new kony.ui.Button({
                "focusSkin": "headerButtonSkin0b7021b36f50840",
                "height": "100%",
                "id": "headerBackButton",
                "isVisible": false,
                "left": 0,
                "right": 0,
                "skin": "headerButtonSkin0b7021b36f50840",
                "text": "Button",
                "top": "0dp",
                "width": "56dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": false,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            headerContainer.add(headerDivider, headerTitle, headerLogoutImage, headerLogoutButton, headerBackChevron, headerBackButton);
            var listContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "id": "listContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox0dc37e8ff906043",
                "top": "60dp",
                "width": "45%"
            }, {}, {});
            listContainer.setDefaultUnit(kony.flex.DP);
            kony.mvc.registry.add('FBox0ef65618e166341', 'FBox0ef65618e166341', 'FBox0ef65618e166341Controller');
            var employeeSegment = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image1.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image2.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image3.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image4.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image5.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image6.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image7.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image8.png",
                    "employeeSegSep": "Label"
                }, {
                    "employeeFieldGroup": "Label",
                    "employeeFieldName": "Label",
                    "employeeFieldTitle": "Label",
                    "employeeId": "Label",
                    "employeeSegImage": "image9.png",
                    "employeeSegSep": "Label"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "employeeSegment",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_a81b0efd866645e0bcd9839b4fbf34c0,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "Copyseg0a7164e19c40c48",
                "rowSkin": "seg0af0513d9aad247",
                "rowTemplate": "FBox0ef65618e166341",
                "sectionHeaderSkin": "sliPhoneSegmentHeader0f0264d1c8de341",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "employeeFieldGroup": "employeeFieldGroup",
                    "employeeFieldName": "employeeFieldName",
                    "employeeFieldTitle": "employeeFieldTitle",
                    "employeeId": "employeeId",
                    "employeeSegImage": "employeeSegImage",
                    "employeeSegSep": "employeeSegSep"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            listContainer.add(employeeSegment);
            var detailContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "detailContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "45%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopydetailContainerSkin0c66cbc5d3a4c41",
                "top": "60dp",
                "verticalScrollIndicator": true,
                "width": "55%"
            }, {}, {});
            detailContainer.setDefaultUnit(kony.flex.DP);
            var detailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "detailsHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopyslFbox0fa636ea1d7714b",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsHeader.setDefaultUnit(kony.flex.DP);
            var detailsHeaderDivision = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "detailsHeaderDivision",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sepLineSkin0jc56bddf12a349",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsHeaderDivision.setDefaultUnit(kony.flex.DP);
            detailsHeaderDivision.add();
            var detailsHeaderTitle = new kony.ui.Label({
                "bottom": "18dp",
                "centerX": "50%",
                "id": "detailsHeaderTitle",
                "isVisible": true,
                "left": "139dp",
                "skin": "CopydefLabel0e64ba49331f649",
                "text": "Employee List",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var detailsLogout = new kony.ui.Image2({
                "centerY": "50%",
                "height": "22dp",
                "id": "detailsLogout",
                "isVisible": true,
                "right": 16,
                "skin": "slImage0e0fb4aee452048",
                "src": "logouticon.png",
                "top": "16dp",
                "width": "22dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var detailsLogoutButton = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0cd563ad946534f",
                "height": "100%",
                "id": "detailsLogoutButton",
                "isVisible": true,
                "onClick": controller.AS_Button_e98496d5716345059d55f34f7de4694d,
                "right": 0,
                "skin": "headerButtonSkin0b7021b36f50840",
                "text": "Button",
                "top": "0dp",
                "width": "56dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": false,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var detailsPrevImage = new kony.ui.Image2({
                "centerY": "50%",
                "height": "18dp",
                "id": "detailsPrevImage",
                "isVisible": true,
                "left": 14,
                "right": 16,
                "skin": "slImage0e0fb4aee452048",
                "src": "backicon.png",
                "top": "16dp",
                "width": "18dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var detailsPrevButton = new kony.ui.Button({
                "focusSkin": "headerButtonSkin0b7021b36f50840",
                "height": "100%",
                "id": "detailsPrevButton",
                "isVisible": true,
                "left": 0,
                "onClick": controller.AS_Button_hd26818bce214325b74cbcb701025aa9,
                "right": 0,
                "skin": "headerButtonSkin0b7021b36f50840",
                "text": "Button",
                "top": "0dp",
                "width": "56dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": false,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            detailsHeader.add(detailsHeaderDivision, detailsHeaderTitle, detailsLogout, detailsLogoutButton, detailsPrevImage, detailsPrevButton);
            var employeeDetailImage = new kony.ui.Image2({
                "centerX": "51.90%",
                "height": "123dp",
                "id": "employeeDetailImage",
                "isVisible": true,
                "left": "7dp",
                "skin": "slImage0e0fb4aee452048",
                "src": "image1.png",
                "top": "26dp",
                "width": "127dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeNameLabel = new kony.ui.Label({
                "centerX": "50%",
                "id": "employeeNameLabel",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0i8b0c121f7e54c",
                "text": "Kenneth George",
                "textStyle": {},
                "top": "166dp",
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeTitleLabel = new kony.ui.Label({
                "centerX": "50.00%",
                "id": "employeeTitleLabel",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0h14d00d3a5ac41",
                "text": "Sales Engineer",
                "textStyle": {},
                "top": "199dp",
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "employeeDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": 20,
                "skin": "slFbox0dc37e8ff906043",
                "top": "284dp"
            }, {}, {});
            employeeDetailsContent.setDefaultUnit(kony.flex.DP);
            var detailsRowContainer1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "detailsRowContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox0dc37e8ff906043",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsRowContainer1.setDefaultUnit(kony.flex.DP);
            var employeeDetailsSegDivide1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "employeeDetailsSegDivide1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "sepLineSkin0jc56bddf12a349",
                "zIndex": 1
            }, {}, {});
            employeeDetailsSegDivide1.setDefaultUnit(kony.flex.DP);
            employeeDetailsSegDivide1.add();
            var employeeDetailsLabel1 = new kony.ui.Label({
                "id": "employeeDetailsLabel1",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0be8647f468774a",
                "text": "EMAIL",
                "textStyle": {},
                "top": 12,
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeDetailsValue1 = new kony.ui.Label({
                "bottom": 12,
                "id": "employeeDetailsValue1",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0cd5fb934035a42",
                "text": "johnson.george@acme.com",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            detailsRowContainer1.add(employeeDetailsSegDivide1, employeeDetailsLabel1, employeeDetailsValue1);
            var detailsRowContainer2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "detailsRowContainer2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox0dc37e8ff906043",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsRowContainer2.setDefaultUnit(kony.flex.DP);
            var employeeDetailsSegDivide2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "employeeDetailsSegDivide2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "sepLineSkin0jc56bddf12a349",
                "zIndex": 1
            }, {}, {});
            employeeDetailsSegDivide2.setDefaultUnit(kony.flex.DP);
            employeeDetailsSegDivide2.add();
            var employeeDetailsLabel2 = new kony.ui.Label({
                "id": "employeeDetailsLabel2",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0be8647f468774a",
                "text": "WORK PHONE",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeDetailsValue2 = new kony.ui.Label({
                "bottom": "12dp",
                "id": "employeeDetailsValue2",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0cd5fb934035a42",
                "text": "+1 321 449 5598",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            detailsRowContainer2.add(employeeDetailsSegDivide2, employeeDetailsLabel2, employeeDetailsValue2);
            var detailsRowContainer3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "detailsRowContainer3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox0dc37e8ff906043",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsRowContainer3.setDefaultUnit(kony.flex.DP);
            var employeeDetailsSegDivide3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "employeeDetailsSegDivide3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "sepLineSkin0jc56bddf12a349",
                "zIndex": 1
            }, {}, {});
            employeeDetailsSegDivide3.setDefaultUnit(kony.flex.DP);
            employeeDetailsSegDivide3.add();
            var employeeDetailsLabel3 = new kony.ui.Label({
                "id": "employeeDetailsLabel3",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0be8647f468774a",
                "text": "DEPARTMENT",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeDetailsValue3 = new kony.ui.Label({
                "bottom": "12dp",
                "id": "employeeDetailsValue3",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0cd5fb934035a42",
                "text": "Platform Management",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            detailsRowContainer3.add(employeeDetailsSegDivide3, employeeDetailsLabel3, employeeDetailsValue3);
            var detailsRowContainer4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "detailsRowContainer4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox0dc37e8ff906043",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            detailsRowContainer4.setDefaultUnit(kony.flex.DP);
            var employeeDetailsSegDivide4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "employeeDetailsSegDivide4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "sepLineSkin0jc56bddf12a349",
                "zIndex": 1
            }, {}, {});
            employeeDetailsSegDivide4.setDefaultUnit(kony.flex.DP);
            employeeDetailsSegDivide4.add();
            var employeeDetailsLabel4 = new kony.ui.Label({
                "id": "employeeDetailsLabel4",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0be8647f468774a",
                "text": "REPORTING TO",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var employeeDetailsValue4 = new kony.ui.Label({
                "bottom": "12dp",
                "id": "employeeDetailsValue4",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopydefLabel0cd5fb934035a42",
                "text": "Ed Gross",
                "textStyle": {},
                "width": kony.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            detailsRowContainer4.add(employeeDetailsSegDivide4, employeeDetailsLabel4, employeeDetailsValue4);
            employeeDetailsContent.add(detailsRowContainer1, detailsRowContainer2, detailsRowContainer3, detailsRowContainer4);
            detailContainer.add(detailsHeader, employeeDetailImage, employeeNameLabel, employeeTitleLabel, employeeDetailsContent);
            var sepLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "id": "sepLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "45%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sepLineSkin0jc56bddf12a349",
                "top": "60dp",
                "width": "2dp",
                "zIndex": 1
            }, {}, {});
            sepLine.setDefaultUnit(kony.flex.DP);
            sepLine.add();
            masterContainer.add(headerContainer, listContainer, detailContainer, sepLine);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "480": {
                    "listContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        }
                    },
                    "detailContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        }
                    },
                    "detailsHeader": {
                        "isVisible": true
                    },
                    "detailsHeaderTitle": {
                        "text": "Employee Details",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        }
                    },
                    "employeeDetailImage": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "86dp"
                        }
                    },
                    "employeeNameLabel": {
                        "top": {
                            "type": "string",
                            "value": "214dp"
                        }
                    },
                    "employeeTitleLabel": {
                        "top": {
                            "type": "string",
                            "value": "259dp"
                        }
                    },
                    "employeeDetailsContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        }
                    },
                    "sepLine": {
                        "isVisible": false
                    }
                },
                "771": {
                    "detailsHeader": {
                        "isVisible": false
                    }
                },
                "1366": {
                    "detailContainer": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "left": {
                            "type": "string",
                            "value": "45.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        }
                    },
                    "detailsHeader": {
                        "isVisible": false
                    }
                }
            }
            this.add(masterContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmEmployee,
            "enabledForIdleTimeout": false,
            "id": "frmEmployee",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [480, 771, 1366],
            "preShow": function(eventobject) {
                controller.AS_Form_ge3d418bd5c6446e82153b121b5481be(eventobject);
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});