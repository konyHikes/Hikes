kony.globals["appid"] = "EmployeeDirectory";
kony.globals["locales"] = [];