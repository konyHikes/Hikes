define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for loginButton **/
    AS_Button_f41bf70e129843ba9b9baa1b11438ea4: function AS_Button_f41bf70e129843ba9b9baa1b11438ea4(eventobject) {
        var self = this;

        function SHOW_ALERT__h90b22b4028a4a778483338422ed2c26_True() {}
        function INVOKE_IDENTITY_SERVICE__aed9e88c3c5c4224995c9f9cf8b02bbe_Success(status, login) {
            var ntf = new kony.mvc.Navigation("frmList");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__aed9e88c3c5c4224995c9f9cf8b02bbe_Failure(status, login) {
            function SHOW_ALERT__h90b22b4028a4a778483338422ed2c26_Callback() {
                SHOW_ALERT__h90b22b4028a4a778483338422ed2c26_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__h90b22b4028a4a778483338422ed2c26_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "employeeLogin$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.usernameTextbox.text;
        login_inputparam["password"] = self.view.passwordTextbox.text;
        employeeLogin$login = mfidentityserviceinvoker("employeeLogin", login_inputparam, INVOKE_IDENTITY_SERVICE__aed9e88c3c5c4224995c9f9cf8b02bbe_Success, INVOKE_IDENTITY_SERVICE__aed9e88c3c5c4224995c9f9cf8b02bbe_Failure);
    }
});