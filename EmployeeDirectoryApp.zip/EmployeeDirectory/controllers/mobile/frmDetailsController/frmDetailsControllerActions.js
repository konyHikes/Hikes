define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for headerLogoutButton **/
    AS_Button_c1a75c6623744453832062c8f5ea24b7: function AS_Button_c1a75c6623744453832062c8f5ea24b7(eventobject) {
        var self = this;

        function SHOW_ALERT__bbf4b0c0705f4d908809bcb9d1a7c59f_True() {}
        function INVOKE_IDENTITY_SERVICE__g96aea8242e34afd8e00f580fd27d932_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__g96aea8242e34afd8e00f580fd27d932_Failure(error) {
            function SHOW_ALERT__bbf4b0c0705f4d908809bcb9d1a7c59f_Callback() {
                SHOW_ALERT__bbf4b0c0705f4d908809bcb9d1a7c59f_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__bbf4b0c0705f4d908809bcb9d1a7c59f_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__g96aea8242e34afd8e00f580fd27d932_Success, INVOKE_IDENTITY_SERVICE__g96aea8242e34afd8e00f580fd27d932_Failure);
    },
    /** onclick defined for headerBackButton **/
    AS_Button_cf35f728c4bd4eae872ab5b0cbfdfb74: function AS_Button_cf35f728c4bd4eae872ab5b0cbfdfb74(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmList");
        ntf.navigate();
    },
    /** preshow defined for frmDetails **/
    AS_Form_aa63d5275ed14441a3f1eb05fddb275e: function AS_Form_aa63d5275ed14441a3f1eb05fddb275e(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__d4d0d07813a048efb18d483c83e6274e_Callback(employees) {
            kony.application.dismissLoadingScreen();
            self.view.employeeDetailsValue1.text = employees["records"][0]["Email"];
            self.view.employeeDetailsValue2.text = employees["records"][0]["Primary_Phone"];
            self.view.employeeNameLabel.text = employees["records"][0]["Name"];
            self.view.employeeDetailImage.src = employees["records"][0]["Image_URL"];
            self.view.employeeTitleLabel.text = employees["records"][0]["Designation"];
            self.view.employeeDetailsValue3.text = employees["records"][0]["Department"];
            self.view.employeeDetailsValue4.text = employees["records"][0]["Manager_Name"];
        }
        kony.application.showLoadingScreen(null, "Fetching Details", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var odataParams = [];
        odataParams.push("$filter=" + "Emp_id eq " + selectedEmployeeId);
        employees_inputparam["options"]["odataurl"] = odataParams.join("&");
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__d4d0d07813a048efb18d483c83e6274e_Callback);
    }
});