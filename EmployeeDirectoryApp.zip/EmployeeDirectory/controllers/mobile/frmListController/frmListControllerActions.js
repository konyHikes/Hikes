define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for headerLogoutButton **/
    AS_Button_ee7133816aee4367839f391cad18dc82: function AS_Button_ee7133816aee4367839f391cad18dc82(eventobject) {
        var self = this;

        function SHOW_ALERT__j62654bbe82244369e382cdeb0f996b6_True() {}
        function INVOKE_IDENTITY_SERVICE__j2b071e76fe847998722025fbc16d4a4_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__j2b071e76fe847998722025fbc16d4a4_Failure(error) {
            function SHOW_ALERT__j62654bbe82244369e382cdeb0f996b6_Callback() {
                SHOW_ALERT__j62654bbe82244369e382cdeb0f996b6_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__j62654bbe82244369e382cdeb0f996b6_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__j2b071e76fe847998722025fbc16d4a4_Success, INVOKE_IDENTITY_SERVICE__j2b071e76fe847998722025fbc16d4a4_Failure);
    },
    /** onrowclick defined for employeeSegment **/
    AS_Segment_bc118b5d1d814ad4a197ae327cd8c1c1: function AS_Segment_bc118b5d1d814ad4a197ae327cd8c1c1(eventobject, sectionNumber, rowNumber) {
        var self = this;
        selectedEmployeeId = this.view.employeeSegment.selectedRowItems[0].employeeId.text;
        var ntf = new kony.mvc.Navigation("frmDetails");
        ntf.navigate();
    },
    /** onmapping defined for frmList **/
    AS_Form_f17f765777a747ee8cf68fa758f1c7ce: function AS_Form_f17f765777a747ee8cf68fa758f1c7ce(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__bcf9cce19eac473b99484c4347ec8049_Callback(employees) {
            kony.application.dismissLoadingScreen();
            var tempCollection9078 = [];
            var tempData4090 = employees.records;
            for (var each in tempData4090) {
                tempCollection9078.push({
                    "employeeFieldTitle": {
                        "text": tempData4090[each]["Designation"]
                    },
                    "employeeFieldGroup": {
                        "text": tempData4090[each]["Department"]
                    },
                    "employeeId": {
                        "text": tempData4090[each]["Emp_id"]
                    },
                    "employeeSegImage": {
                        "src": tempData4090[each]["Image_URL"]
                    },
                    "employeeFieldName": {
                        "text": tempData4090[each]["Name"]
                    },
                });
            }
            self.view.employeeSegment.setData(tempCollection9078);
        }
        kony.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__bcf9cce19eac473b99484c4347ec8049_Callback);
    }
});