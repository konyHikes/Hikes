define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for loginButton **/
    AS_Button_e6443f9fefbd48b4a5d13aaa143791eb: function AS_Button_e6443f9fefbd48b4a5d13aaa143791eb(eventobject) {
        var self = this;

        function SHOW_ALERT__b9ee266415f1419a9f75da9e9ef3e356_True() {}
        function INVOKE_IDENTITY_SERVICE__dfe3a05a37af4dbe8a3ef4ae2a809370_Success(response) {
            var ntf = new kony.mvc.Navigation("frmList");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__dfe3a05a37af4dbe8a3ef4ae2a809370_Failure(error) {
            function SHOW_ALERT__b9ee266415f1419a9f75da9e9ef3e356_Callback() {
                SHOW_ALERT__b9ee266415f1419a9f75da9e9ef3e356_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__b9ee266415f1419a9f75da9e9ef3e356_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "employeeLogin$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.usernameTextbox.text;
        login_inputparam["password"] = self.view.passwordTextbox.text;
        employeeLogin$login = mfidentityserviceinvoker("employeeLogin", login_inputparam, INVOKE_IDENTITY_SERVICE__dfe3a05a37af4dbe8a3ef4ae2a809370_Success, INVOKE_IDENTITY_SERVICE__dfe3a05a37af4dbe8a3ef4ae2a809370_Failure);
    },
    /** onClick defined for loginButton **/
    AS_Button_f3178959046b4301993adaa2719a61e4: function AS_Button_f3178959046b4301993adaa2719a61e4(eventobject) {
        var self = this;

        function SHOW_ALERT__j9f7b610e1eb4004a5eaa33267677fd2_True() {}
        function INVOKE_IDENTITY_SERVICE__f8531704f9f64da284401acd3483ff81_Success(response) {
            var ntf = new kony.mvc.Navigation("frmList");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__f8531704f9f64da284401acd3483ff81_Failure(error) {
            function SHOW_ALERT__j9f7b610e1eb4004a5eaa33267677fd2_Callback() {
                SHOW_ALERT__j9f7b610e1eb4004a5eaa33267677fd2_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Authentication Failed!",
                "alertHandler": SHOW_ALERT__j9f7b610e1eb4004a5eaa33267677fd2_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "employeeLogin$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.usernameTextbox.text;
        login_inputparam["password"] = self.view.passwordTextbox.text;
        employeeLogin$login = mfidentityserviceinvoker("employeeLogin", login_inputparam, INVOKE_IDENTITY_SERVICE__f8531704f9f64da284401acd3483ff81_Success, INVOKE_IDENTITY_SERVICE__f8531704f9f64da284401acd3483ff81_Failure);
    }
});