define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for headerLogoutButton **/
    AS_Button_c3c22fb1a3a147678f7dc74a1ce1fee8: function AS_Button_c3c22fb1a3a147678f7dc74a1ce1fee8(eventobject) {
        var self = this;

        function SHOW_ALERT__e37fd2ce8cc84c0583f2aa490bb28b69_True() {}
        function INVOKE_IDENTITY_SERVICE__cbfddcdab42a4c778b17160b6231ee6d_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__cbfddcdab42a4c778b17160b6231ee6d_Failure(error) {
            function SHOW_ALERT__e37fd2ce8cc84c0583f2aa490bb28b69_Callback() {
                SHOW_ALERT__e37fd2ce8cc84c0583f2aa490bb28b69_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__e37fd2ce8cc84c0583f2aa490bb28b69_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__cbfddcdab42a4c778b17160b6231ee6d_Success, INVOKE_IDENTITY_SERVICE__cbfddcdab42a4c778b17160b6231ee6d_Failure);
    },
    /** onrowclick defined for employeeSegment **/
    AS_Segment_ce3a21e8b0374dcc83650de7b116c97c: function AS_Segment_ce3a21e8b0374dcc83650de7b116c97c(eventobject, sectionNumber, rowNumber) {
        var self = this;
        selectedEmployeeId = this.view.employeeSegment.selectedRowItems[0].employeeId.text;
        var ntf = new kony.mvc.Navigation("frmDetails");
        ntf.navigate();
    },
    /** onmapping defined for frmList **/
    AS_Form_f137f613a1034f27ab9f758ce187856f: function AS_Form_f137f613a1034f27ab9f758ce187856f(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__a927b7e02a554f5c8f9ef347c0ba849a_Callback(employees) {
            var tempCollection8149 = [];
            var tempData54 = employees.records;
            for (var each in tempData54) {
                tempCollection8149.push({
                    "employeeId": {
                        "text": tempData54[each]["Emp_id"]
                    },
                    "employeeFieldGroup": {
                        "text": tempData54[each]["Designation"]
                    },
                    "employeeFieldTitle": {
                        "text": tempData54[each]["Department"]
                    },
                    "employeeFieldName": {
                        "text": tempData54[each]["Name"]
                    },
                    "employeeSegImage": {
                        "src": tempData54[each]["Image_URL"]
                    },
                });
            }
            self.view.employeeSegment.setData(tempCollection8149);
        }
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__a927b7e02a554f5c8f9ef347c0ba849a_Callback);
    }
});