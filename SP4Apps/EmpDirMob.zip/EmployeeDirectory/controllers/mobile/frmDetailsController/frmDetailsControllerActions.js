define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for headerLogoutButton **/
    AS_Button_df8a343f702b42d2a49ed2544a907574: function AS_Button_df8a343f702b42d2a49ed2544a907574(eventobject) {
        var self = this;

        function SHOW_ALERT__ad5faca4972d4ee9a8399de478fdbca5_True() {}
        function INVOKE_IDENTITY_SERVICE__c88f2c6063554f17ba94eb5cf6884788_Success(response) {
            var ntf = new kony.mvc.Navigation("frmLogin");
            ntf.navigate();
        }
        function INVOKE_IDENTITY_SERVICE__c88f2c6063554f17ba94eb5cf6884788_Failure(error) {
            function SHOW_ALERT__ad5faca4972d4ee9a8399de478fdbca5_Callback() {
                SHOW_ALERT__ad5faca4972d4ee9a8399de478fdbca5_True();
            }
            kony.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Logout Failed!",
                "alertHandler": SHOW_ALERT__ad5faca4972d4ee9a8399de478fdbca5_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        if (logout_inputparam == undefined) {
            var logout_inputparam = {};
        }
        logout_inputparam["serviceID"] = "employeeLogin$logout";
        logout_inputparam["operation"] = "logout";
        employeeLogin$logout = mfidentityserviceinvoker("employeeLogin", logout_inputparam, INVOKE_IDENTITY_SERVICE__c88f2c6063554f17ba94eb5cf6884788_Success, INVOKE_IDENTITY_SERVICE__c88f2c6063554f17ba94eb5cf6884788_Failure);
    },
    /** onclick defined for headerBackButton **/
    AS_Button_bfc64c6d54f54bbabc5086be43b8cb0d: function AS_Button_bfc64c6d54f54bbabc5086be43b8cb0d(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmList");
        ntf.navigate();
    },
    /** preshow defined for frmDetails **/
    AS_Form_h31775c79e5a4f48a55eacc64ab6377b: function AS_Form_h31775c79e5a4f48a55eacc64ab6377b(eventobject) {
        var self = this;

        function INVOKE_OBJECT_SERVICE__cab6aef1c97f4b56bfcd447b199fb37d_Callback(employees) {
            self.view.employeeDetailImage.src = employees["records"][0]["Image_URL"];
            self.view.employeeNameLabel.text = employees["records"][0]["Name"];
            self.view.employeeTitleLabel.text = employees["records"][0]["Designation"];
            self.view.employeeDetailsValue1.text = employees["records"][0]["Email"];
            self.view.employeeDetailsValue2.text = employees["records"][0]["Primary_Phone"];
            self.view.employeeDetailsValue3.text = employees["records"][0]["Department"];
            self.view.employeeDetailsValue4.text = employees["records"][0]["Manager_Name"];
        }
        if (employees_inputparam == undefined) {
            var employees_inputparam = {};
        }
        employees_inputparam["serviceID"] = "EmployeeServices$employees$get";
        employees_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var odataParams = [];
        odataParams.push("$filter=" + "Emp_id eq " + selectedEmployeeId);
        employees_inputparam["options"]["odataurl"] = odataParams.join("&");
        var employees_httpheaders = {};
        employees_inputparam["httpheaders"] = employees_httpheaders;
        var employees_httpconfigs = {};
        employees_inputparam["httpconfig"] = employees_httpconfigs;
        EmployeeServices$employees$get = mfobjectsecureinvokerasync(employees_inputparam, "EmployeeServices", "employees", INVOKE_OBJECT_SERVICE__cab6aef1c97f4b56bfcd447b199fb37d_Callback);
    }
});